You can find the AviTab manual at https://github.com/fpw/avitab/wiki
