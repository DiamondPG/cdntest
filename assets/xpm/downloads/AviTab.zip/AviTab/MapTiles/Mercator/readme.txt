PDF or image files placed into this directory can be used as a moving map
inside AviTab. Only Mercator maps are supported, i.e. the latitudes and longitudes
must be straight lines.

On first usage, the file has to be calibrated by you. The instructions are shown
inside AviTab when enabling plane tracking after opening the map.
