Place GeoTIFF files in here. You can also create nested subdirectories to
organize your files.

Note that the GeoTIFF files from OpenFlightMaps use an unsupported projection,
use their EPSG-3857 tiles instead.

You can find great GeoTIFF files for the US here:
https://www.faa.gov/air_traffic/flight_info/aeronav/digital_products/vfr/
Simply place the TIF files from the ZIP files into here, the other files are not needed.
